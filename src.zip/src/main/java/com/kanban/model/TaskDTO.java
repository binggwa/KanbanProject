package com.kanban.model;

import java.time.LocalDate;

public class TaskDTO {
    public String id;
    public String title;
    public String description;
    public LocalDate dueDate;
    public String priority;
    public String tag;

    // Jackson 기본 생성자
    public TaskDTO() {}

    // Task → TaskDTO로 변환하는 생성자
    public TaskDTO(Task task) {
        this.id = task.getId();
        this.title = task.getTitle();
        this.description = task.getDescription();
        this.dueDate = task.getDueDate();
        this.priority = task.getPriority();
        this.tag = task.getTag();
    }

    // TaskDTO → Task로 변환하는 메서드
    public Task toTask() {
        Task task = new Task(title, description, dueDate, priority, tag);
        task.setId(id); // 원래 ID 유지
        return task;
    }
}
