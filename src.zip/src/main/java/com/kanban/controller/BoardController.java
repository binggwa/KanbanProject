package com.kanban.controller;

import com.kanban.model.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BoardController {
    @FXML
    private Button addNewColumn;

    @FXML
    private ScrollPane scrollPane;

    @FXML
    private VBox taskContainer;

    @FXML
    private VBox rootVBox;  // VBox 전체 UI

    private HBox columnContainer; // 동적으로 컬럼들을 넣을 컨테이너

    private final List<Task> taskList = new ArrayList<>();

    public void setTaskList(List<Task> tasks) {
        taskList.clear();
        taskList.addAll(tasks);
        refreshUI();
    }

    public List<Task> getTaskList() {
        return new ArrayList<>(taskList); // 복사본 반환
    }

    private void refreshUI() {
        taskContainer.getChildren().clear(); // 기존 UI 삭제

        for (Task task : taskList) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/kanban/view/TaskCard.fxml"));
                Parent taskCard = loader.load();

                TaskCardController controller = loader.getController();
                controller.setTask(task); // TaskCard에 Task 데이터 전달

                taskContainer.getChildren().add(taskCard); // VBox에 추가

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    public void initialize() {
        // 초기화 시 ScrollPane 내부에 컬럼을 담을 HBox를 동적으로 생성
        columnContainer = new HBox(20); // 컬럼 사이 간격
        columnContainer.setPrefHeight(400);
        scrollPane.setContent(columnContainer);
    }

    @FXML
    private void onAddColumnClicked() {
        try {
            // ColumnView.fxml 파일을 불러와 하나의 컬럼으로 추가
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/kanban/view/ColumnView.fxml"));
            AnchorPane column = loader.load();  // AnchorPane 또는 VBox 등 ColumnView의 루트 타입
            columnContainer.getChildren().add(column);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}