package com.kanban.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.layout.AnchorPane;
import com.kanban.model.Task;
import javafx.stage.Stage;
import javafx.stage.Modality;
import javafx.scene.Scene;


import java.io.IOException;

public class ColumnController {
    @FXML
    private Label columnTitleLabel;

    @FXML
    private VBox taskListContainer;

    @FXML
    private Button addTaskButton;

    /**
     * Add Task 버튼 클릭 시 호출되는 메서드
     */
    @FXML
    private void onAddTaskClicked() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com.kanban/view/TaskInputForm.fxml"));
            AnchorPane formPane = loader.load();

            // 팝업용 스테이지 생성
            Stage dialog = new Stage();
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.setTitle("Add New Task");

            Scene scene = new Scene(formPane);
            dialog.setScene(scene);

            // 컨트롤러 연결
            TaskInputFormController controller = loader.getController();
            controller.setDialogStage(dialog);

            dialog.showAndWait();

            Task task = controller.getCreatedTask();
            if (task != null) {
                // TaskCard.fxml 파일을 로드
                FXMLLoader cardLoader = new FXMLLoader(getClass().getResource("/com/kanban/view/TaskCard.fxml"));
                AnchorPane taskCard = cardLoader.load();

                // TaskCardController와 연동
                // 1. 컨트롤러 가져오기
                TaskCardController cardController = cardLoader.getController();

                // 2. Task 객체 생성 (샘플 값. 실제론 사용자 입력 받아 생성하는 게 좋음)
                // Task newTask = new Task("New Task", LocalDate.now().plusDays(3), Task.Priority.MEDIUM, List.of("sample"));
                // UI 생성 제작완료로 주석처리

                // 3. TaskCard UI에 Task 내용 세팅
                cardController.setTask(task);

                // 4. 삭제 시 동작 설정 (자기 자신을 taskListContainer에서 제거)
                cardController.setOnDeleteCallback(() -> taskListContainer.getChildren().remove(taskCard));

                // 5. 화면에 추가
                taskListContainer.getChildren().add(taskCard);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * 외부에서 컬럼 제목 설정할 수 있게 하는 메서드
     */
    public void setColumnTitle(String title) {
        columnTitleLabel.setText(title);
    }

    /**
     * TaskCard를 외부에서 추가하고 싶을 때 사용
     */
    public void addTaskCard(AnchorPane taskCard) {
        taskListContainer.getChildren().add(taskCard);
    }
}