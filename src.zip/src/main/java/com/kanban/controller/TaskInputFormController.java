package com.kanban.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.stage.Stage;
import com.kanban.model.Task;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public class TaskInputFormController {
    @FXML private TextField titleField;
    @FXML private DatePicker dueDatePicker;
    @FXML private ChoiceBox<String> priorityChoiceBox;
    @FXML private TextField tagsField;
    @FXML private Button cancelButton;
    @FXML private Button addButton;

    private Stage dialogStage;
    private boolean confirmed = false;

    public void setDialogStage(Stage stage) {
        this.dialogStage = stage;
    }

    private Task createdTask;

    @FXML
    private void initialize() {
        // 초기화 시 priorityChoiceBox에 값 설정
        priorityChoiceBox.getItems().addAll("LOW", "MEDIUM", "HIGH");
    }

    @FXML
    private void onAdd() {
        String title = titleField.getText();
        LocalDate dueDate = dueDatePicker.getValue();
        String priority = priorityChoiceBox.getValue();
        List<String> tags = Arrays.asList(tagsField.getText().split(",\\s*"));

        createdTask = new Task(title, dueDate, priority, tags);
        // 추가 후 폼을 닫는 동작은 호출 측에서 처리
    }

    @FXML
    private void onCancel() {
        createdTask = null;
    }

    public Task getCreatedTask() {
        return createdTask;
    }
}
