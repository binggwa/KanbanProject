package com.kanban;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import com.kanban.model.Task;
import com.kanban.util.TaskPersistence;
import com.kanban.controller.BoardController;

import java.io.File;
import java.util.List;

public class MainApp extends Application {

    private static final File DATA_FILE = new File(System.getProperty("user.home"), "kanban_tasks.json");
    private BoardController mainController;  // 컨트롤러 저장

    @Override
    public void start(Stage primaryStage) throws Exception {
        // FXML 로드
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/kanban/view/MainView.fxml"));
        Parent root = loader.load();

        // 컨트롤러 가져오기
        mainController = loader.getController();

        // JSON에서 작업 불러오기
        List<Task> loadedTasks = TaskPersistence.loadTasks(DATA_FILE);
        mainController.setTaskList(loadedTasks); // 컨트롤러에 리스트 전달

        // Scene 세팅 (크기 자유롭게 조절 가능)
        Scene scene = new Scene(root, 800, 600);

        // Stage 설정
        primaryStage.setTitle("Kanban To-Do Board");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @Override
    public void stop() throws Exception {
        super.stop();
        if (mainController != null) {
            List<Task> currentTasks = mainController.getTaskList(); // 현재 작업 가져오기
            TaskPersistence.saveTasks(currentTasks, DATA_FILE);     // JSON 저장
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
