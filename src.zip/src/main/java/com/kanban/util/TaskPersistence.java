package com.kanban.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.kanban.model.Task;
import com.kanban.model.TaskDTO;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TaskPersistence {
    private static final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule()) // LocalDate 직렬화 지원
            .enable(SerializationFeature.INDENT_OUTPUT); // 보기 좋게 출력

    public static void saveTasks(List<Task> tasks, File file) throws IOException {
        List<TaskDTO> dtoList = tasks.stream().map(Task::toDTO).toList();
        mapper.writeValue(file, dtoList);
    }

    public static List<Task> loadTasks(File file) throws IOException {
        if (!file.exists()) return new ArrayList<>();

        CollectionType listType = mapper.getTypeFactory()
                .constructCollectionType(List.class, TaskDTO.class);

        List<TaskDTO> dtoList = mapper.readValue(file, listType);
        return dtoList.stream().map(TaskDTO::toTask).toList();
    }
}
